from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import json
from datetime import datetime
from налаштування import TOKEN

ФАЙЛ_КЛІЄНТИ = "клієнти.json"

def завантажити_дані():
    try:
        with open(ФАЙЛ_КЛІЄНТИ, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def зберегти_дані(дані):
    with open(ФАЙЛ_КЛІЄНТИ, "w", encoding="utf-8") as f:
        json.dump(дані, f, indent=2, ensure_ascii=False)

async def старт(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        ["Старт", "Бро", "Info", "✅ Використав знижку", "❌ Не використав знижку"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

    await update.message.reply_text(
        "👋 Вітаю! Введи номер клієнта або вибери дію:",
        reply_markup=reply_markup
    )

async def інфо(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["очікуємо_інфо"] = True
    await update.message.reply_text("✏️ Введи номер клієнта для перегляду інформації.")

async def recommend(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["чекає_номер_друга"] = True
    await update.message.reply_text("✏️ Введи номер друга який порекомендував таксі БогDan Drive:")

async def відмітити_знижку(update: Update, context: ContextTypes.DEFAULT_TYPE, використав: bool):
    context.user_data["відмітка_знижки"] = використав
    await update.message.reply_text(
        "✅ Знижка буде вважатися "
        + ("використаною." if використав else "невикористаною й перейде на наступну поїздку.")
    )

async def обробити_повідомлення(update: Update, context: ContextTypes.DEFAULT_TYPE):
    текст = update.message.text.strip()

    if текст == "✅ Використав знижку":
        await відмітити_знижку(update, context, використав=True)
        return
    if текст == "❌ Не використав знижку":
        await відмітити_знижку(update, context, використав=False)
        return

    if context.user_data.get("очікуємо_інфо"):
        номер = текст.replace(" ", "").replace("-", "").replace("(", "").replace(")", "").strip()
        дані = завантажити_дані()
        клієнт = дані.get(номер)
        if клієнт:
            повідомлення = (
                f"Інформація про клієнта {номер}:\n"
                f"Кількість замовлень: {клієнт['orders']}\n"
                f"Знижка -10%: {'так' if клієнт.get('has_discount_10') else 'ні'}\n"
                f"Знижка -20%: {'так' if клієнт.get('has_discount_20') else 'ні'}"
            )
        else:
            повідомлення = "Клієнта з таким номером не знайдено."
        await update.message.reply_text(повідомлення)
        context.user_data["очікуємо_інфо"] = False
        return

    # Очистка номера від пробілів, дужок, дефісів
    номер = текст.replace(" ", "").replace("-", "").replace("(", "").replace(")", "").strip()

    # Перевірка формату номера
    if not (номер.startswith("+380") and len(номер) == 13 and номер[1:].isdigit()):
        await update.message.reply_text("❗️ Будь ласка, введи номер у форматі +380XXXXXXXXX")
        return

    дані = завантажити_дані()

    # Запам'ятовуємо поточного клієнта
    context.user_data["номер_клієнта"] = номер

    # Обробка введення номера друга, якщо очікуємо
    if context.user_data.get("чекає_номер_друга"):
        context.user_data["чекає_номер_друга"] = False
        номер_друга = номер
        номер_клієнта = context.user_data.get("номер_клієнта")

        if номер_друга not in дані:
            await update.message.reply_text("❗️ Номер друга не знайдено в базі. Він має спочатку скористатись таксі.")
            return

        if not номер_клієнта:
            await update.message.reply_text("⚠️ Спочатку введи свій номер клієнта, перш ніж вводити номер друга.")
            return

        клієнт = дані.get(номер_клієнта, {
            "orders": 0,
            "order_history": [],
            "has_discount_10": False,
            "has_discount_20": False,
            "referred_by": None,
            "invited": [],
            "telegram_id": None
        })

        if клієнт.get("referred_by"):
            await update.message.reply_text("⚠️ Ви вже вказали друга.")
            return

        клієнт["referred_by"] = номер_друга
        клієнт["has_discount_10"] = True

        # Зберігаємо клієнта, якщо він був новий
        дані[номер_клієнта] = клієнт

        # Додаємо знижку другу
        друг = дані.get(номер_друга, {
            "orders": 0,
            "order_history": [],
            "has_discount_10": False,
            "has_discount_20": False,
            "referred_by": None,
            "invited": [],
            "telegram_id": None
        })

        друг["has_discount_10"] = True
        друг.setdefault("invited", []).append(номер_клієнта)
        дані[номер_друга] = друг

        зберегти_дані(дані)

        await update.message.reply_text("✅ Знижка -10% нарахована вам і другу, який вас запросив 🎉")
        return

    # Якщо це просто номер клієнта (без очікування друга)
    клієнт = дані.setdefault(номер, {
        "orders": 0,
        "order_history": [],
        "has_discount_10": False,
        "has_discount_20": False,
        "referred_by": None,
        "invited": [],
        "telegram_id": None
    })

    клієнт["orders"] += 1
    клієнт["order_history"].append(datetime.now().strftime("%Y-%m-%d %H:%M"))

    повідомлення = f"📲 Це {клієнт['orders']}-те замовлення клієнта."

    знижки = []

    if клієнт.get("has_discount_10"):
        if context.user_data.get("відмітка_знижки") is True:
            знижки.append("-10% за друга")
            клієнт["has_discount_10"] = False
        elif context.user_data.get("відмітка_знижки") is False:
            знижки.append("-10% зберігається")
        else:
            знижки.append("-10% (не вказано, використано чи ні)")

    if клієнт["orders"] % 5 == 0:
        знижки.append("-20% постійна знижка")

    if знижки:
        повідомлення += " 🎉 Активні знижки: " + ", ".join(знижки)
    else:
        повідомлення += " ❗️Знижки наразі немає."

    зберегти_дані(дані)
    await update.message.reply_text(повідомлення)

# --- Запуск додатку ---
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", старт))
app.add_handler(CommandHandler("info", інфо))
app.add_handler(CommandHandler("bro", recommend))
app.add_handler(MessageHandler(filters.Regex("^Старт$"), старт))
app.add_handler(MessageHandler(filters.Regex("^Бро$"), recommend))
app.add_handler(MessageHandler(filters.Regex("^Info$"), інфо))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, обробити_повідомлення))

app.run_polling()